<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Subcategory;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Auth;
class CategoryController extends Controller
{
    // CategoryController.php


    
public function create()
{
    return view('categories.create');
}

public function store(Request $request)
{
    $request->validate([
        'name' => 'required|unique:categories',
    ]);


    $category = Category::create($request->all());

    return redirect()->route('categories.index')->with('success', 'Category created successfully');
}

    public function index()
    {
        
        // $categories = Category::all();
        // return view('categories.index', compact('categories'));
        $categories = Category::with('subcategories')->get();
        
        return view('categories.index', compact('categories'));

        
    }

    // public function createSubcategoryForm($categoryId)
    // {
    //     $category = Category::findOrFail($categoryId);
    //     $categories = Category::all(); 
    //     return view('categories.create-subcategory', compact('category', 'categories'));
    // }

    public function storeSubcategory(Request $request)
    {
        try {
            $categoryId = $request->input('category');
            $subcategoryName = $request->input('subcategory');

            // Save the subcategory to the database
            $subcategory = new Subcategory();
            $subcategory->name = $subcategoryName;
            $subcategory->category_id = $categoryId;
            $subcategory->save();

            return redirect()->route('categories.index')->with('success', 'Subcategory added successfully');
        } catch (QueryException $e) {
            $errorCode = $e->errorInfo[1];

            if ($errorCode == 1062) { // Duplicate entry error code
                return redirect()->route('categories.index')->with('error', 'Subcategory already exists');
            }

            // Handle other database-related errors as needed
            return redirect()->route('categories.index')->with('error', 'Error adding subcategory');
        }
    }

    // public function showSelected(Request $request)
    // {
    //     $selectedCategoryId = $request->input('category');
    //     $selectedCategory = Category::find($selectedCategoryId);

    //     // You can use $selectedCategory as needed

    //     return view('categories.selected', compact('selectedCategory'));
    // }

}
