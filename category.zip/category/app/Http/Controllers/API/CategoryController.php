<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\QueryException;
use App\Models\Subcategory;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::with('subcategories')->get();

        return response()->json(['categories' => $categories], 200);
    }

    public function store(Request $request)
    {
    
   
        try {
            $validator = Validator::make($request->all(), [
                'category_id' => 'required|exists:categories,id',
                'name' => 'required|string|unique:subcategories|max:255',
            ]);

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 422);
            }

            // Save the subcategory to the database
            $subcategory = new Subcategory();
            $subcategory->name = $request->input('name');
            $subcategory->category_id = $request->input('category_id');
            $subcategory->save();

            return response()->json(['success' => 'Subcategory added successfully'], 201);
        } catch (QueryException $e) {
            $errorCode = $e->errorInfo[1];

            if ($errorCode == 1062) { // Duplicate entry error code
                return response()->json(['error' => 'Subcategory already exists'], 409);
            }

            // Handle other database-related errors as needed
            return response()->json(['error' => 'Error adding subcategory'], 500);
        }
    
}

}
