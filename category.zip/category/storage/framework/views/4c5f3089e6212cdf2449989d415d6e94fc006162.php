<h1>Add Subcategory for <?php echo e($category->name); ?></h1>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form method="post" action="<?php echo e(route('categories.store-subcategory', $category)); ?>">
    <?php echo csrf_field(); ?>
    <label for="name">Subcategory Name:</label>
    <input type="text" name="name" id="name" required>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <button type="submit">Add Subcategory</button>
</form>
<?php /**PATH C:\xampp\htdocs\category\resources\views/categories/create-subcategory.blade.php ENDPATH**/ ?>