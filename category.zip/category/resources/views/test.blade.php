<!-- resources/views/test.blade.php -->

@extends('layouts.app')

@section('content')
    <a href="{{ route('categories.create') }}">Create Category</a>
@endsection
