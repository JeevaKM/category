<h1>Add Subcategory for {{ $category->name }}</h1>

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<form method="post" action="{{ route('categories.store-subcategory', $category) }}">
    @csrf
    <label for="name">Subcategory Name:</label>
    <input type="text" name="name" id="name" required>
    @error('name')
        <div class="alert alert-danger">{{ $message }}</div>
    @enderror
    <button type="submit">Add Subcategory</button>
</form>
