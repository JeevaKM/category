<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <title>Category and Subcategory Management</title>
</head>
<body>
    <div class="container mt-5">
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif

        <div class="mb-4">
            <a href="{{ route('categories.create') }}" class="btn btn-primary">Create Category</a>
        </div>

        <h1>Add Subcategory</h1>
        <form action="{{ route('categories.store-subcategory') }}" method="post" class="mb-4">
            @csrf
            <div class="form-group">
                <label for="category">Select Category:</label>
                <select id="category" name="category" class="form-control">
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}">{{ $category->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="subcategory">Subcategory Name:</label>
                <input type="text" id="subcategory" name="subcategory" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Add Subcategory</button>
        </form>

        <h1>All Categories with Subcategories</h1>
        @foreach($categories as $category)
            <div class="card mt-4">
                <div class="card-header">
                    <h2>{{ $category->name }}</h2>
                </div>
                <div class="card-body">
                    @if($category->subcategories->count() > 0)
                        <ul>
                            @foreach($category->subcategories as $subcategory)
                                <li>{{ $subcategory->name }}</li>
                            @endforeach
                        </ul>
                    @else
                        <p>No subcategories for this category.</p>
                    @endif
                </div>
            </div>
        @endforeach
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
