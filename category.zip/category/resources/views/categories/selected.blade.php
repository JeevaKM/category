<!-- resources/views/categories/selected.blade.php -->

<h1>Selected Category: {{ $selectedCategory->name }}</h1>
<!-- Add content to display details of the selected category -->
