<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\CategoryController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('test');
});

Auth::routes();

//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
// routes/web.php

// Route::middleware(['auth', 'isAdmin'])->group(function () {
//     Route::get('/categories/create', [App\Http\Controllers\CategoryController::class,'create'])->name('categories.create');
//     Route::post('/categories', [App\Http\Controllers\CategoryController::class,'store'])->name('categories.store');
//    // Route::get('/categories', [App\Http\Controllers\CategoryController::class,'create'])->name('categories.index');
//     // routes/web.php
// Route::get('/categories', [CategoryController::class, 'index'])->name('categories.index');
// // Route::get('/categories/{category}/add-subcategory', [CategoryController::class, 'createSubcategoryForm'])->name('categories.create-subcategory-form');
// Route::post('/categories/{category}/add-subcategory', [CategoryController::class, 'storeSubcategory'])->name('categories.store-subcategory');
// Route::post('/categories/store-subcategory', [CategoryController::class, 'storeSubcategory'])->name('categories.store-subcategory');

// });
Route::get('/categories/create', [CategoryController::class,'create'])->name('categories.create');
Route::post('/categories', [CategoryController::class,'store'])->name('categories.store');
Route::get('/categories', [CategoryController::class, 'index'])->name('categories.index');
//Route::post('/categories/{category}/add-subcategory', [CategoryController::class, 'storeSubcategory'])->name('categories.store-subcategory');
Route::post('/categories/store-subcategory', [CategoryController::class, 'storeSubcategory'])->name('categories.store-subcategory');
